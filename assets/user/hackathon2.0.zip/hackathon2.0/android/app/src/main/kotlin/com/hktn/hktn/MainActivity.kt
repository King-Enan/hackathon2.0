package com.hktn.hktn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
