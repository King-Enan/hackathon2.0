import 'package:flutter/material.dart';
class chk extends StatefulWidget {
  const chk({super.key});

  @override
  State<chk> createState() => _chkState();
}

class _chkState extends State<chk> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("chkj"),
      ),
    );
  }
}
